__version__ = '1.1.2.dev20260602+0be5eaa7'
