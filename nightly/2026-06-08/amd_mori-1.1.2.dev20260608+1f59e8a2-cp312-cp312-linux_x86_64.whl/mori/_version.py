__version__ = '1.1.2.dev20260608+1f59e8a2'
