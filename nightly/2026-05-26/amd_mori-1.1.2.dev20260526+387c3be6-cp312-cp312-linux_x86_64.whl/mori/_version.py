__version__ = '1.1.2.dev20260526+387c3be6'
