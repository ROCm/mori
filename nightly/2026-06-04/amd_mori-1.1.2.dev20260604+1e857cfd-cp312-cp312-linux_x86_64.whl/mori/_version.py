__version__ = '1.1.2.dev20260604+1e857cfd'
