__version__ = '1.1.2.dev20260601+0be5eaa7'
